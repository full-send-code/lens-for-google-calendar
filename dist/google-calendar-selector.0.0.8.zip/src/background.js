// setTimeout( () => chrome.browserAction.disable(), 5000 )
